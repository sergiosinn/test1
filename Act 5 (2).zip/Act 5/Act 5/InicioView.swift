//
//  InicioView.swift
//  Act 5
//
//  Created by Angel Jael on 27/02/24.
//  Copyright © 2024 Angel Jael. All rights reserved.
//

import SwiftUI

struct InicioView: View {
    var body: some View {
        Text("Bienvenido")
        .padding(60)
    }
}

struct InicioView_Previews: PreviewProvider {
    static var previews: some View {
        InicioView()
    }
}
