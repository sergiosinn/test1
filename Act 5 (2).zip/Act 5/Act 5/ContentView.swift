
//
//  ContentView.swift
//  1er
//
//  Created by Angel Jael on 24/02/24.
//  Copyright © 2024 Angel Jael. All rights reserved.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        
         TabView {
                    NavigationView {
                        InicioView()
                            .navigationBarTitle("Pantalla de bienvenida", displayMode: .inline)
                    }
                    .tabItem {
                        Image(systemName: "1.circle.fill")
                        Text("Pantalla de Inicio")
                    }

                    NavigationView {
                        ProgramadorView()
                            .navigationBarTitle("Programa 2", displayMode: .inline)
                    }
                    .tabItem {
                        Image(systemName: "2.circle.fill")
                        Text("Calificaciones")
            }
            
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
