//  ContentView.swift
//  basico1
//
//  Created by Alumno on 22/02/24.
//
import SwiftUI

struct sProgramador {
    let id: Int
    let nombre: String
    let avatar: String
    let lenguaje: String
}

let programadores = [
    sProgramador(id: 1, nombre: "Francisco", avatar: "person.fill", lenguaje: "Swift,Java"),
    sProgramador(id: 2, nombre: "Jael", avatar: "person.fill", lenguaje: "C, HTML"),
    sProgramador(id: 3, nombre: "Mario", avatar: "person.fill", lenguaje: "Python"),
    sProgramador(id: 4, nombre: "Carmen", avatar: "person.fill", lenguaje: "Windev, c++"),
    sProgramador(id: 5, nombre: "Diego", avatar: "person.fill", lenguaje: "React, Ruby")
]

struct ProgramadorView: View {
    @State private var nombre: String = ""
    @State private var miToggle: Bool = true
    @State private var edad: Int = 0
    @State private var miSlider: Float = 0.0
    @State private var editando: Bool = false
    @State private var MostrarAlerta = false
    @State private var ProgramadorSeleccionado: sProgramador?

    var body: some View {
        VStack {
            Form {
                Section(header: Text("configuracion")) {
                    Stepper(value: $edad, in: 0...Int.max, step: 1) {
                        Text("Edad: \(edad)")
                    }
                    
                    TextField("Captura tu nombre: ", text: $nombre)
                    Text("Nombre registrado: \(nombre)")
                }

                Section(header: Text("Utilerias")) {
                    Toggle("Encender", isOn: $miToggle)
                    Text("\(miToggle.description)")
                    Slider(value: $miSlider, in: 0...10, step: 1, onEditingChanged: { (editing) in
                        self.editando = editing
                    }, minimumValueLabel: Text("Min"), maximumValueLabel: Text("Max")) {
                        Text("Selecciona la calificacion")
                    }
                    Text("\(miSlider)")
                        .bold()
                        .foregroundColor(editando ? .red : .blue)
                }

                Section(header: Text("PROGRAMADORES 1")) {
                    List {
                        ForEach(programadores, id: \.nombre) { sProgramador in
                            VStack {
                                HStack {
                                    Image(systemName: sProgramador.avatar)
                                        .resizable()
                                        .frame(width: 30,  height: 30 )
                                        .shadow(color: .blue, radius: 10)

                                    Text(sProgramador.nombre)
                                        .onTapGesture {
                                            self.ProgramadorSeleccionado = sProgramador
                                            self.MostrarAlerta = true
                                        }
                                }
                            }
                        }
                    }
                }

                Section(header: Text("PROGRAMADORES 2")) {
                    List {
                        ForEach(programadores, id: \.nombre) { sProgramador in
                            VStack {
                                HStack {
                                    Image(systemName: sProgramador.avatar)
                                        .resizable()
                                        .frame(width: 30,  height: 30 )
                                        .shadow(color: .blue, radius: 10)

                                  .onTapGesture {
                                      self.ProgramadorSeleccionado = sProgramador
                                      self.MostrarAlerta = true
                                  }
                                                                
                                    Text(sProgramador.nombre)
                                        .font(.title)
                                }
                                Text(sProgramador.lenguaje)
                            }
                        }
                    }
                }

                Section(header: Text("PROGRAMADORES 3")) {
                    List {
                        ForEach(programadores, id: \.nombre) { sProgramador in
                            VStack {
                                HStack {
                                    Image(systemName: sProgramador.avatar)
                                        .resizable()
                                        .frame(width: 30,  height: 30 )
                                        .shadow(color: .blue, radius: 10)
                                        
                                        Text(sProgramador.nombre)
                                        Text(sProgramador.lenguaje)
                                    .onTapGesture {
                                        self.ProgramadorSeleccionado = sProgramador
                                        self.MostrarAlerta = true
                                    }
                                    
                                }
                            }
                        }
                    }
                }
            }
            .background(EmptyView().alert(isPresented: $MostrarAlerta) {
                Alert(title: Text("Nombre del Programador"), message: Text(ProgramadorSeleccionado?.nombre ?? ""), dismissButton: .default(Text("OK")))
            })
            .padding()
        }
    }
}

struct ProgramadorView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
